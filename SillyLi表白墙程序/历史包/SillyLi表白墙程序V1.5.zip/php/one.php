<?php
include '../header.php';
$id = xss_clean(daddslashes($_GET['id']));

  $sql = "SELECT * FROM `sillyli_lovemsg` WHERE id=$id";
  $num = $conn->query($sql);
  $row = $num->fetchAll();
  $i=0;
?>
<div class="wrap">
<div class="main">
	<div class="point">
		<div class="zzan" style="right:10px;" >
			<a href="javascript:" class="jzan"><span id="<?php echo $id = $row[$i]['id'] ?>"><?php echo $row[$i]['zan'] ?></span><img src="/images/zan.png" alt="" class="zan"/></a>	
		</div>
			<div class="ptop">
				<img src="<?php 
                          if($row[$i]['qq'] !== ''){
                          echo "https://q.qlogo.cn/headimg_dl?dst_uin=".$row[$i]['qq']."&spec=100";
                          }else{
                          echo "//yun.sillyli.com/img/tx/tx_".rand(1,17).".jpg";
                          }
                          ?>" alt="" class="avatar">
				<div class="pp">
				<span class="pname">
                  <?php 
                    if($row[$i]['realname']){
                     echo $row[$i]['realname'];
                    }else{
                      echo $row[$i]['qq'];
                    }
                  ?></span><br><span class="ptime"><?php echo date("Y-m-d H:i:s",$row[$i]['time']) ?></span>
				</div>
			</div>
			<div class="pmain">
				<p><span class="towho"><?php echo $row[$i]['towho'] ?></span><?php echo $row[$i]['msg'] ?></p>
			</div>
			<div class="pf">
				<ul id="reply-<?php echo $id ?>" class="hidethis">
                  <?php
                    $sqls = "SELECT * FROM `sillyli_reply` WHERE `gid` = '$id' ";
                    $nums = $conn->query($sqls);
                    $rows = $nums->fetchALL();
                    $n = count($rows);
                    if($n > 0){
                    $e = 0;
                    while($e < $n){
                        echo "<li class='replys'><p><span class='replyname'>".$rows[$e]['nname']."</span>：".$rows[$e]['reply']."</p></li>";
                        $e++;
                      }
                    }
                  ?>
				</ul>
				<a href="javascript:" class="more">点击展开更多...</a>
				<script>
				$(function(){
					if($("#reply-245").height()>100){
								$("#reply-245").css({"height":"100px","overflow":"hidden"});
								$("#reply-245").next().show();
							}
				})
				</script>
				<form action="" method="post" onsubmit="return false">
					<div class="line">
						<input type="text" name="reply" placeholder="我也说两句" class="pliu">
						<div class="pjiao" id="<?php echo $id ?>">提交</div>
					</div>
				</form>
			</div>
		</div>	
  <div class="point">
				<p>复制本页面链接，或分享此页面仅展示你的表白哦！</p>
		</div>	
  </div>