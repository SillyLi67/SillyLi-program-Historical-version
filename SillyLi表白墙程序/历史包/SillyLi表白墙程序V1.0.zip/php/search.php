<?php
include 'common.php';

$p = $_POST['k'];
$k = $_GET['k'];

if($p !== '' and $k == ''){
  $sql = "SELECT * FROM `sillyli_lovemsg` WHERE `msg` LIKE '%".$p."%' ";
  $num = $conn->query($sql);
  $row = $num->fetch();
  if(!$row){
    die('0');
  }
  die('1');
}
  $sql = "SELECT * FROM `sillyli_lovemsg` WHERE `msg` LIKE '%".$p."%' ";
  $num = $conn->query($sql);
  $row = $num->fetchAll();
?>
<div class="wrap">
<div class="main">
<?php
  $j = count($row);
  $i = 0;
  while($i <= $j-1 ){
?>
	<div class="point">
		<div class="zzan">
			<a href="javascript:" class="jzan"><span id="<? echo $id = $row[$i]['id'] ?>"><? echo $row[$i]['zan'] ?></span><img src="/images/zan.png" alt="" class="zan"></a>	
		</div>
			<div class="ptop">
				<img src="<? 
                          if($row[$i]['qq'] !== ''){
                          echo "https://q.qlogo.cn/headimg_dl?dst_uin=".$row[$i]['qq']."&spec=100";
                          }
                          
                          ?>" alt="" class="avatar">
				<div class="pp">
				<span class="pname"><? echo $row[$i]['realname'] ?></span><br><span class="ptime"><? echo date("Y-m-d H:i:s",$row[$i]['time']) ?></span>
				</div>
			</div>
			<div class="pmain">
				<p><span class="towho"><? echo $row[$i]['towho'] ?></span><? echo $row[$i]['msg'] ?></p>
			</div>
			<div class="pf">
				<ul id="reply-<? echo $id ?>" class="hidethis">
                  <?php
                    $sqls = "SELECT * FROM `sllyli_reply` WHERE `gid` = '$id' ";
                    $nums = $conn->query($sqls);
                    $rows = $nums->fetchALL();
                    $n = count($rows);
                    if($n > 0){
                    $e = 0;
                    while($e < $n){
                        echo "<li class='replys'><p><span class='replyname'>".$rows[$e]['nname']."</span>：".$rows[$e]['reply']."</p></li>";
                        $e++;
                      }
                    }
                  ?>
				</ul>
				<a href="javascript:" class="more">点击展开更多...</a>
				<script>
				$(function(){
					if($("#reply-245").height()>100){
								$("#reply-245").css({"height":"100px","overflow":"hidden"});
								$("#reply-245").next().show();
							}
				})
				</script>
				<form action="" method="post" onsubmit="return false">
					<div class="line">
						<input type="text" name="reply" placeholder="我也说两句" class="pliu">
						<div class="pjiao" id="<? echo $id ?>">提交</div>
					</div>
				</form>
			</div>
		</div>	
 <? $i++; }

include '../foot.php';
?>