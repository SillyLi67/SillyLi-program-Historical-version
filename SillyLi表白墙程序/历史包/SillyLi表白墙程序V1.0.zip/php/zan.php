<?php
include 'common.php';

$id = $_POST['gid'];

$sql = "UPDATE `sillyli_lovemsg` SET `zan` = zan + 1 WHERE `id` = '".$id."'";
$conn->query($sql);
echo '1';