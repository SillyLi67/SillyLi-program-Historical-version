<?php
include 'common.php';

$gid = $_POST['id'];
$reply = $_POST['reply'];
$qq = $_POST['qq'];
$nname = $_POST['nname'];
$time = time();

if($reply== '' or $gid == ''){ die('error'); }

if($reply !== '' and $nname == ''){
  $qq = $_COOKIE["qq"];
  $nname = $_COOKIE["nname"];
}
if($nname == ''){
  setcookie("nname",'',time()-3600,"/");
  die('-1');
}
if($qq == ''){
  setcookie("qq",'',time()-3600,"/");
  die('-1');
}

setcookie("qq",$qq,time()+3600,"/");
setcookie("nname",$nname,time()+3600,"/");

$sql = "INSERT INTO `sillyli_reply`(`gid`, `qq`, `nname`, `reply`, `time`) VALUES ('".$gid."','".$qq."','".$nname."','".$reply."','".$time."')";
$conn->query($sql);
echo '1';


?>